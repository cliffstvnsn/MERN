import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello Dojo</h1>
      <h2>Things I need to do:</h2>
      <u1>
        <li>Learn React</li>
        <li>Finish this assignment</li>
        <li>Exercise</li>
        <li>Wash dishes</li>
      </u1>
    </div>
  );
}

export default App;
